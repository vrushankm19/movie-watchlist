// src/components/Watchlist.js
import React from 'react';

const Watchlist = ({ watchlist, onRemove }) => (
  <div>
    <h2>Your Watchlist</h2>
    {watchlist.map(movie => (
      <div key={movie.imdbID}>
        <h3>{movie.Title} ({movie.Year})</h3>
        <button onClick={() => onRemove(movie.imdbID)}>Remove</button>
      </div>
    ))}
  </div>
);

export default Watchlist;
